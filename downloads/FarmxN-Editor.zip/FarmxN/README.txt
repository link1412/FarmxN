Farm x N — Offline Editor

Open index.html in a modern browser. Images and map data are embedded; no server, Node.js or game installation is required to edit.
Export Farm.tmx and load it using SMAPI + Content Patcher with your own Stardew Valley installation.
The default 2048 x 2048 content pack is a separate download.
For fun and creative play: back up your saves and start a NEW standard farm.

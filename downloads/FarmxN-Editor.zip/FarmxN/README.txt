FarmxN — Offline Editor

Open index.html in a modern browser. Images and map data are embedded; no server, Node.js or game installation is required to edit.
Export Farm.tmx and load it using SMAPI + Content Patcher with your own Stardew Valley installation.
The default 160 x 130 content pack is a separate download.
This is a pre-release; full in-game testing is pending.

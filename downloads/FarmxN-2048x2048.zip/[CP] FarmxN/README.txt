Farm x N — 2048 x 2048 Standard Farm (Farm x 806.6)

Requires Stardew Valley 1.6, SMAPI 4 and Content Patcher.
Copy [CP] FarmxN into the game Mods directory. Launch via SMAPI and start a NEW standard farm.
For fun and creative play: back up your saves first.
Install only ONE Farm x N map pack. Do not enable another mod which also replaces Maps/Farm.
Large maps use more memory and may take longer to load. Use the editor to make a smaller map if needed.

2048 × 2048 标准农场。安装 SMAPI 和 Content Patcher 后，将 [CP] FarmxN 放入 Mods，使用 SMAPI 启动并新建标准农场。
建议娱乐体验，请先备份存档并开新档。只安装一个 Farm x N 地图包，请勿同时启用其他标准农场替换模组。
大地图需要更多内存和加载时间，可用编辑器自行缩小地图。

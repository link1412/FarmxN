FarmxN — Default 160 x 130 Standard Farm

Requires Stardew Valley 1.6, SMAPI 4 and Content Patcher.
Copy [CP] FarmxN into the game Mods directory. Launch via SMAPI and start a NEW standard farm.
Do not enable another mod which also replaces Maps/Farm.
This is a pre-release: full in-game event, multiplayer and seasonal testing is pending.

默认 160 × 130 标准农场。安装 SMAPI 和 Content Patcher 后，将 [CP] FarmxN 放入 Mods，启动并新建标准农场。
请勿同时启用其他替换 Maps/Farm 的模组。当前为预发布，完整游戏流程尚未验证。
